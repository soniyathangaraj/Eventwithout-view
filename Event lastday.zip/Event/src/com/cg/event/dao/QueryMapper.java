package com.cg.event.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_QUERY="SELECT * FROM customer_details";
	
	public static final String VIEW_CUSTOMER_DETAILS_QUERY="select * from customer_details where customerId=?";
	public static final String INSERT_QUERY="INSERT INTO customer_details VALUES(CUSTOMERId_sequence.NEXTVAL,?,?,?,SYSDATE)";
	public static final String CUSTOMERID_QUERY_SEQUENCE="select max(customerId) from  Customer_details";
	

}
