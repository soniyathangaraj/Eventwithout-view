package com.cg.event.service;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.event.bean.EventBean;
import com.cg.event.dao.EventDaoImpl;
import com.cg.event.dao.IEventDao;
import com.cg.event.exception.EventException;

public class EventServiceImpl implements IEventService{
	static IEventDao eventdao=new EventDaoImpl();

	public String addEvent(EventBean event) throws EventException {
		// TODO Auto-generated method stub
		String eventSeq;
		eventSeq=eventdao.addEvent(event);
		return eventSeq;
		
	}

	@Override
	public EventBean viewEventDetails(String customerId) throws EventException, SQLException {
		System.out.println(customerId);
		EventBean eventBean=new EventBean();
				eventBean=eventdao.viewEventDetails(customerId);
	
		return eventBean;
		
		
		
		
		
	}
	

	@Override
	public List retrieveAll() throws EventException {
		// TODO Auto-generated method stub
		eventdao=new EventDaoImpl();
		List<EventBean> eventList=null;
		eventList=eventdao.retrieveAll();
		return eventList;
		
	}
	
	public boolean validateEvent(EventBean bean) throws EventException
	{
		List<String> validationErrors=new ArrayList<String>();
		if(!(isValidName(bean.getCustomerName())))
		{
			validationErrors.add("\n customer name should be Alphabets and minimum 3 characters long!\n");
		}
		if(!(isValidAddress(bean.getAddress())))
		{
			validationErrors.add("\n Address should be greater than 5 characters!\n");
		}
		if(!(isValidPhoneNumber(bean.getPhoneNumber())))
		{
			validationErrors.add("\nphone number should be in 10 digits");
		}
		if(!(isValidAmount(bean.getPayAmount())))
		{
			validationErrors.add("\n Amount should be positive");
		}
		
		if(!validationErrors.isEmpty())
			return false;
			
	
	return true;
	}

	private boolean isValidAmount(double payAmount) {
		// TODO Auto-generated method stub
		return payAmount>0;
	}

	private boolean isValidPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
	
	}

	private boolean isValidAddress(String address) {
		// TODO Auto-generated method stub
		return (address.length() > 5);
	}

	private boolean isValidName(String customerName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customerName);
		return nameMatcher.matches();
		
	}

	

	
	

}
