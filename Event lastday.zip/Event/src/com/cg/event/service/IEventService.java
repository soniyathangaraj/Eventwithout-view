package com.cg.event.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.event.bean.EventBean;
import com.cg.event.exception.EventException;



public interface IEventService {

	public String addEvent(EventBean event) throws EventException;
	public EventBean viewEventDetails(String customerId) throws EventException, SQLException;
	public List retrieveAll() throws EventException;
	

}
