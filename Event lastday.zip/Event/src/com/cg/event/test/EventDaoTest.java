package com.cg.event.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.event.bean.EventBean;
import com.cg.event.dao.EventDaoImpl;
import com.cg.event.exception.EventException;



public class EventDaoTest {
	static EventDaoImpl dao;
	static EventBean event;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new EventDaoImpl();
		event = new EventBean();
	}

	@Test
	public void testaddEvent() throws EventException {

		assertNotNull(dao.addEvent(event));

	}

	
	@Ignore
	@Test
	public void testaddEvent1() throws EventException {
		// increment the number next time you test for positive test case
		assertEquals(100, dao.addEvent(event));
	}

	
	@Test
	public void testaddevent2() throws EventException {

		event.setCustomerName("Shashwathi");
		event.setPhoneNumber("9876543210");
		event.setAddress("whitefield");
		
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addEvent(event)) > 100);

	}

	

	@Test
	public void testById() throws EventException, SQLException {
		assertNotNull(dao.viewEventDetails("101"));
	}

	@Ignore
	@Test
	public void testById1() throws EventException, SQLException {
		assertEquals("TestName", dao.viewEventDetails("101").getCustomerName());
	}

}
